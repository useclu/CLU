<template>
  <div class="picto">
    <div class="layer1" />
    <div class="layer2" />
  </div>
</template>

<style scoped lang="scss">
.picto {
  position: relative;
  min-width: 1em;
  min-height: 1em;

  .layer1 {
    mask: url(assets/svg/modes/noctilien_1.svg) no-repeat center;
    background-color: #000;
    mask-size: contain;
  }

  .layer2 {
    mask: url(assets/svg/modes/noctilien_2.svg) no-repeat center;
    background-color: #FF1400;
    mask-size: contain;
  }

  & > div {
    position: absolute;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
  }
}
</style>