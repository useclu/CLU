<script setup lang="ts">
import { useResizeObserver } from '@vueuse/core'
import {
  computed,
  inject,
  onUnmounted,
  ref,
  watch,
} from 'vue'
import { useProject } from '~/stores/useProject'
import { StopContextKey } from '~/utils/symbols'

type TramStyle =
  | 'ANGLED'
  | 'HORIZONTAL'

const {
  value,
  placeName = '',
  subtitle = '',
  interestPoint = false,
  accessible = 'undefined',
  reverse = false,
  future = false,
  nameStyle,
  terminusArrow = false,
  terminusArrowText = null,
  branchStart = false,
} = defineProps<{
  value: string
  placeName?: string | null
  subtitle?: string | null
  interestPoint?: boolean
  reverse?: boolean
  accessible?: boolean | 'undefined' | undefined
  future?: boolean
  nameStyle?: StopNameStyle
  terminusArrow?: boolean
  terminusArrowText?: string | null
  branchStart?: boolean
}>()

const stopContext = inject<StopContext>(StopContextKey)!

const project = useProject()

const effectiveValue = computed(() =>
  value.trim(),
)

const effectiveTerminusArrowText =
  computed(() =>
    terminusArrowText?.trim() ?? '',
  )

const showTerminusArrow =
  computed(
    () =>
      terminusArrow
      && effectiveTerminusArrowText.value.length > 0,
  )

const terminusArrowSymbol =
  computed(() =>
    branchStart
      ? '←'
      : '→',
  )

/*
 * =========================================================
 * NOM MULTILIGNE
 * =========================================================
 */

const valueParts = computed(() =>
  value
    .split('\n')
    .filter(part => part.trim() !== ''),
)

const isMultiline = computed(() =>
  valueParts.value.length > 1,
)

const hasSubtitle = computed(() =>
  Boolean(subtitle?.trim()),
)

/*
 * =========================================================
 * TRAMWAY
 * =========================================================
 */

const isTramMode = computed(() =>
  project.line.mode === 'TRAM',
)

const tramStyle = computed<TramStyle>(() =>
  (
    project.line as Line & {
      tramStyle?: TramStyle
    }
  ).tramStyle
  ?? 'ANGLED',
)

const isTramHorizontal = computed(() =>
  isTramMode.value
  && tramStyle.value === 'HORIZONTAL',
)

const isTramAngled = computed(() =>
  isTramMode.value
  && tramStyle.value === 'ANGLED',
)

/*
 * =========================================================
 * POSITION DU TERMINUS TRAM
 * =========================================================
 *
 * On applique volontairement le déplacement directement
 * sur le wrapper avec :style.
 *
 * Cela évite qu'une autre règle CSS ne remplace
 * accidentellement la position du terminus.
 *
 * HORIZONTAL :
 * le déplacement est effectué sur
 * .tram-terminus-content plus bas.
 *
 * ANGLED 1 ligne :
 * -1.65em
 *
 * ANGLED plusieurs lignes :
 * -2.35em
 */
const tramWrapperStyle = computed(() => {
  if (!isTramMode.value) {
    return undefined
  }

  if (isTramHorizontal.value) {
    return {
      transform: 'none',
    }
  }

  if (isTramAngled.value) {
    const baseShift =
      isMultiline.value
        ? -2.85
        : -1.65

    /*
     * Un sous-titre de terminus incliné est le contenu le plus proche
     * du point. On éloigne donc directement l'ANCRE complète du cartouche.
     * C'est plus fiable qu'un padding dans le bloc déjà tourné.
     */
    const subtitleClearance =
      hasSubtitle.value
        ? .32
        : 0

    const shift = reverse
      ? baseShift + subtitleClearance
      : baseShift - subtitleClearance

    return {
      transform:
        `translateY(${shift}em)`,
    }
  }

  return undefined
})

const frame = ref<HTMLDivElement | null>(null)

const { stop } = useResizeObserver(
  frame,
  e => updateMargins(
    e[0].target as HTMLDivElement,
  ),
)

watch(
  stopContext.inverted,
  () => {
    if (frame.value) {
      updateMargins(frame.value)
    }
  },
)

watch(
  [
    () => interestPoint,
    () => subtitle,
    isTramMode,
  ],
  ([
    _interestPoint,
    _subtitle,
    _isTramMode,
  ]) => {
    /*
     * En Tram, le sous-titre est directement
     * intégré au bloc du terminus.
     */
    if (_isTramMode) {
      stopContext.margins.rightMargin.subtitle =
        '0em'

      return
    }

    let margin = 1

    if (_interestPoint) {
      margin += 0.5
    }

    if (_subtitle) {
      stopContext.margins.rightMargin.subtitle =
        `${margin}em`
    }
    else {
      stopContext.margins.rightMargin.subtitle =
        '0em'
    }
  },
  { immediate: true },
)

function updateMargins(element: HTMLElement) {
  /*
   * =======================================================
   * TRAMWAY HORIZONTAL
   * =======================================================
   *
   * La largeur réelle du cartouche participe
   * directement au layout.
   */
  if (isTramHorizontal.value) {
    stopContext.margins.leftMargin.name = '0px'
    stopContext.margins.rightMargin.name = '0px'

    return
  }

  const size = element.offsetHeight

  if (reverse) {
    stopContext.margins.rightMargin.name =
      `calc(${size * 2}px - 1.5em)`

    stopContext.margins.leftMargin.name =
      '0px'
  }
  else {
    stopContext.margins.leftMargin.name =
      `calc(${size * 2}px - 1.5em)`

    stopContext.margins.rightMargin.name =
      '0px'
  }
}

onUnmounted(() => {
  stop()

  stopContext.margins.rightMargin.name = '0px'
  stopContext.margins.leftMargin.name = '0px'
})
</script>

<template>
  <div
    class="terminus-label"
    :class="{
      reverse,
      future,
      'tram-mode': isTramMode,
      'tram-horizontal': isTramHorizontal,
      'tram-angled': isTramAngled,
      'tram-multiline': isMultiline,
      'tram-has-subtitle': isTramMode && hasSubtitle,
    }"
    :style="tramWrapperStyle"
  >
    <div
      v-if="showTerminusArrow"
      class="terminus-line-direction"
      :class="{
        reverse,
        'branch-start': branchStart,
      }"
    >
      <span class="terminus-line-direction-arrow">
        {{ terminusArrowSymbol }}
      </span>

      <span class="terminus-line-direction-text">
        {{ effectiveTerminusArrowText }}
      </span>
    </div>

    <!--
      ======================================================
      TRAMWAY
      ======================================================
    -->
    <TiltedText
      v-if="isTramMode"
      :reverse="reverse"
    >
      <div
        ref="frame"
        class="tram-terminus-content"
        :class="{
          'opacity-50 export-hide':
            !effectiveValue,
        }"
      >
        <div class="title-holder">
          <TerminusLabel
            :value="
              effectiveValue
              || $t(
                'ui.map_editor.toolbox.untitled_stop',
              )
            "
            :place-name="placeName"
            :name-style="nameStyle"
          />

          <Wheelchair
            v-if="
              accessible !== 'undefined'
            "
            class="tram-terminus-wheelchair"
            :off="!accessible"
          />
        </div>

        <StopSubtitle
          v-if="subtitle"
          class="tram-terminus-subtitle"
          :interest-point="interestPoint"
          :value="subtitle"
        />
      </div>
    </TiltedText>

    <!--
      ======================================================
      RENDU CLASSIQUE
      ======================================================
    -->
    <template v-else>
      <TiltedText :reverse="reverse">
        <div
          ref="frame"
          class="flex flex-col items-end gap-1"
          :class="{
            'opacity-50 export-hide':
              !effectiveValue,
          }"
        >
          <div class="title-holder">
            <TerminusLabel
              :value="
                effectiveValue
                || $t(
                  'ui.map_editor.toolbox.untitled_stop',
                )
              "
              :place-name="placeName"
              :name-style="nameStyle"
            />

            <Wheelchair
              v-if="
                accessible !== 'undefined'
              "
              :off="!accessible"
            />
          </div>

          <StopSubtitle
            v-if="subtitle && reverse"
            :interest-point="interestPoint"
            :value="subtitle"
          />
        </div>
      </TiltedText>

      <TiltedText
        v-if="subtitle && !reverse"
        class="subtitle-holder"
        :class="{
          'interest-point': interestPoint,
        }"
      >
        <StopSubtitle
          :interest-point="interestPoint"
          :value="subtitle"
        />
      </TiltedText>
    </template>
  </div>
</template>

<style scoped lang="scss">
.terminus-label {
  position: relative;

  display: flex;
  flex-direction: row;

  align-items: end;

  gap: .75em;

  transform:
    translateY(-.125em);

  width: 1em;
  height: 0;

  transition:
    opacity .2s ease,
    filter .2s ease;

  &.future {
    opacity: .55;
  }

  .reverse & {
    transform:
      translateY(.125em);
  }
}

/*
 * =========================================================
 * TITRE
 * =========================================================
 */

.title-holder {
  display: flex;
  flex-direction: row;

  align-items: center;

  gap: .25em;

  .reverse & {
    flex-direction: row-reverse;
  }
}

.terminus-line-direction {
  position: absolute;

  top: .55em;
  left: 1.25em;

  display: flex;
  flex-direction: row;
  align-items: center;

  gap: .32em;

  width: max-content;
  max-width: 24em;

  color: #000;

  opacity: 1 !important;
  filter: none !important;

  font-size: .78em;
  font-weight: 700;
  line-height: 1;

  white-space: nowrap;

  pointer-events: none;
  z-index: 30;

  &.reverse {
    flex-direction: row-reverse;
  }

  &.branch-start {
    right: 2.5em;
    left: auto;

    flex-direction: row-reverse;
  }
}

.terminus-line-direction-arrow {
  display: inline-flex;

  align-items: center;
  justify-content: center;

  flex-shrink: 0;

  color: #000;

  font-size: 1.45em;
  font-weight: 700;
  line-height: .85;
}

.terminus-line-direction-text {
  display: block;

  max-width: 22em;

  overflow: hidden;

  color: #000;

  text-overflow: ellipsis;
}

/*
 * =========================================================
 * TRAMWAY
 * =========================================================
 */

.tram-terminus-content {
  display: flex;
  flex-direction: column;

  align-items: center;

  width: max-content;

  gap: .18em;
}

/*
 * =========================================================
 * TRAMWAY HORIZONTAL — UNE LIGNE
 * =========================================================
 */

.terminus-label.tram-horizontal {
  width: max-content;
  min-width: max-content;

  .tram-terminus-content {
    width: max-content;
    min-width: max-content;

    transform:
      translateY(-1.15em);
  }

  .tram-terminus-subtitle {
    display: block;

    width: max-content;

    align-self: center;

    line-height: 1;
  }

  /*
   * PMR spécifique au cartouche Horizontal.
   */
  .tram-terminus-wheelchair {
    position: relative;

    top: -.38em;

    flex-shrink: 0;
  }
}

/*
 * =========================================================
 * TRAMWAY HORIZONTAL — PLUSIEURS LIGNES
 * =========================================================
 */

.terminus-label.tram-horizontal.tram-multiline {
  .tram-terminus-content {
    /*
     * Ton réglage multiligne horizontal actuel.
     */
    transform:
      translateY(-2.50em);
  }

  .tram-terminus-wheelchair {
    top: -.48em;
  }
}

/*
 * =========================================================
 * TRAMWAY INCLINÉ
 * =========================================================
 *
 * IMPORTANT :
 *
 * le déplacement vertical du wrapper Incliné n'est
 * PLUS défini ici.
 *
 * Il est maintenant appliqué directement par Vue
 * dans tramWrapperStyle.
 *
 * Ça permet de garantir :
 *
 * 1 ligne      -> -1.65em
 * plusieurs    -> -2.35em
 */

.terminus-label.tram-angled {
  width: 1em;

  .tram-terminus-content {
    align-items: flex-start;

    position: relative;

    top: 0;
  }

  .tram-terminus-subtitle {
    display: block;

    width: max-content;

    align-self: flex-start;

    line-height: 1;
  }
}

/*
 * =========================================================
 * TRAMWAY INCLINÉ — DÉGAGEMENT DU SOUS-TITRE TERMINUS
 * =========================================================
 *
 * Le terminus est ancré par le bas dans TiltedText. Avec un
 * sous-titre, c'est donc ce dernier qui se retrouvait au plus près
 * du point. On ajoute une zone de respiration sous le contenu afin
 * de garder le sous-titre clairement séparé du cercle de station,
 * y compris avec un cartouche long.
 */
.terminus-label.tram-angled.tram-has-subtitle {
  .tram-terminus-subtitle {
    /*
     * Le terminus ne remonte plus tout le cartouche pour créer le dégagement.
     * Le sous-titre reste près du point, mais avec une respiration nette sous
     * le nom du terminus.
     */
    margin-top: -.10em;

    opacity: .72;
  }

  :deep(.tram-terminus-subtitle.subtitle) {
    /*
     * Un sous-titre Tram doit être clairement secondaire : plus petit et
     * moins massif que le nom de station, tout en conservant l'italique.
     */
    font-size: .43em;
    font-weight: 600;
    letter-spacing: .012em;
  }
}

/*
 * =========================================================
 * SOUS-TITRE CLASSIQUE
 * =========================================================
 */

.subtitle-holder {
  --initial: -.75;
  --interest-point: 0;

  transform:
    translateX(
      calc(
        (
          var(--initial)
          + var(--interest-point)
        )
        * 1em
      )
    );

  width: 0;

  &.interest-point {
    --interest-point: .5;
  }
}
</style>