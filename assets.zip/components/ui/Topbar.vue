<script setup lang="ts">
import { storeToRefs } from 'pinia'
import { computed, ref } from 'vue'
import { useI18n } from 'vue-i18n'
import { useRoute } from '#app'
import useCluPreviewMode, { type PreviewMode } from '~/composables/useCluPreviewMode'
import { useProject } from '~/stores/useProject'
import { useSnow } from '~/stores/useSnow'

const project = useProject()
const { canUndo, canRedo } = storeToRefs(project)
const { undo, redo } = project

const { snowEnabled, isWinter } = storeToRefs(useSnow())

const route = useRoute()
const normalizedRoutePath = computed(() => route.path.replace(/\/+$/, '') || '/')
const isEditorRoute = computed(() => normalizedRoutePath.value === '/editor')
const isGameRoute = computed(() => normalizedRoutePath.value === '/game')
const {
  previewMode,
  isPreviewing,
  setPreviewMode,
  exitPreview,
} = useCluPreviewMode()
const isEditorPreview = computed(
  () => isEditorRoute.value && isPreviewing.value,
)
const isRatpEditorPreview = computed(
  () =>
    isEditorRoute.value
    && previewMode.value === 'RATP',
)
const { t } = useI18n()

const showMenu = ref(false)

const showLineIndexDirectory = ref(false)
const showModePictogramsDialog = ref(false)
const showSaveDialog = ref(false)
const showCustomMapSizeDialog = ref(false)
const customMapSize = ref<string | number | null>(null)
const showCustomLineThicknessDialog = ref(false)
const customLineThickness = ref<string | null>(null)

const filePopover = ref()
const toolsPopover = ref()
const previewPopover = ref()
const utilityPopover = ref()

const previewOptions: Array<{
  mode: PreviewMode
  labelKey: string
  icon: string
}> = [
  {
    mode: 'SNCF',
    labelKey: 'ui.map_editor.preview_mode_sncf',
    icon: 'i-tabler-train',
  },
  {
    mode: 'RATP',
    labelKey: 'ui.map_editor.preview_ratp',
    icon: 'i-tabler-route',
  },
]

function previewModeLabelKey(
  mode: PreviewMode,
) {
  return previewOptions.find(
    option => option.mode === mode,
  )?.labelKey
  ?? 'ui.map_editor.preview'
}

const previewButtonLabel = computed(() => {
  if (!previewMode.value) {
    return t('ui.map_editor.preview')
  }

  return t(
    'ui.map_editor.preview_current',
    {
      mode: t(
        previewModeLabelKey(
          previewMode.value,
        ),
      ),
    },
  )
})

function toggleFileMenu(event: Event) {
  toolsPopover.value?.hide()
  previewPopover.value?.hide()
  utilityPopover.value?.hide()
  filePopover.value?.toggle(event)
}

function toggleToolsMenu(event: Event) {
  filePopover.value?.hide()
  previewPopover.value?.hide()
  utilityPopover.value?.hide()
  toolsPopover.value?.toggle(event)
}

function closeFilePopover() {
  filePopover.value?.hide()
}

function openCustomIndices() {
  closeFilePopover()
  showMenu.value = false
  showLineIndexDirectory.value = true
}

function openModePictograms() {
  closeFilePopover()
  showMenu.value = false
  showModePictogramsDialog.value = true
}

function openSave() {
  closeFilePopover()
  showMenu.value = false
  showSaveDialog.value = true
}

function openCustomMapSize() {
  toolsPopover.value?.hide()
  showMenu.value = false
  customMapSize.value = project.line.mapSize
  showCustomMapSizeDialog.value = true
}

function cancelCustomMapSize() {
  showCustomMapSizeDialog.value = false
  customMapSize.value = project.line.mapSize
}

function applyCustomMapSize() {
  if (
    customMapSize.value === null
    || customMapSize.value === ''
  ) {
    cancelCustomMapSize()
    return
  }

  project.line.mapSize = customMapSize.value
  showCustomMapSizeDialog.value = false
}

function openCustomLineThickness() {
  toolsPopover.value?.hide()
  showMenu.value = false
  customLineThickness.value = project.line.lineThickness
  showCustomLineThicknessDialog.value = true
}

function cancelCustomLineThickness() {
  showCustomLineThicknessDialog.value = false
  customLineThickness.value = project.line.lineThickness
}

function applyCustomLineThickness() {
  if (
    customLineThickness.value === null
    || customLineThickness.value === ''
  ) {
    cancelCustomLineThickness()
    return
  }

  project.line.lineThickness = customLineThickness.value
  showCustomLineThicknessDialog.value = false
}

function togglePreviewMenu(event: Event) {
  filePopover.value?.hide()
  toolsPopover.value?.hide()
  utilityPopover.value?.hide()
  previewPopover.value?.toggle(event)
}

function toggleUtilityMenu(event: Event) {
  filePopover.value?.hide()
  toolsPopover.value?.hide()
  previewPopover.value?.hide()
  utilityPopover.value?.toggle(event)
}

function closeUtilityMenu() {
  utilityPopover.value?.hide()
}

function selectPreviewMode(
  mode: PreviewMode,
) {
  setPreviewMode(mode)

  filePopover.value?.hide()
  toolsPopover.value?.hide()
  previewPopover.value?.hide()
  utilityPopover.value?.hide()
}

function selectPreviewModeFromMobile(
  mode: PreviewMode,
) {
  selectPreviewMode(mode)
  showMenu.value = false
}

function returnToEditing() {
  exitPreview()
  previewPopover.value?.hide()
}

function returnToEditingFromMobile() {
  returnToEditing()
  showMenu.value = false
}

function toggleSnow() {
  snowEnabled.value = !snowEnabled.value
}
</script>

<template>
  <template v-if="!isGameRoute">
    <Menubar class="bulb-topbar">
    <template #start>
      <div class="topbar-left">
        <!--
          =====================================================
          IDENTITÉ CLU
          =====================================================
        -->
        <div class="brand">
          <h1 class="brand-title">
            <strong class="text-nowrap hidden 2xl:block">
              {{ $t('ui.topbar.brand') }}
            </strong>

            <strong class="text-nowrap 2xl:hidden visible">
              CLU
            </strong>
          </h1>
        </div>

        <!--
          =====================================================
          FICHIER / OUTILS
          =====================================================
        -->
        <div class="hidden lg:flex topbar-actions">
          <Button
            :label="$t('ui.topbar.file')"
            icon="i-tabler-file"
            severity="secondary"
            text
            @click="toggleFileMenu"
          />

          <Button
            v-if="!isEditorPreview"
            :label="$t('ui.topbar.tools')"
            icon="i-tabler-adjustments-horizontal"
            severity="secondary"
            text
            @click="toggleToolsMenu"
          />

          <Button
            v-if="isEditorRoute"
            :label="previewButtonLabel"
            icon="i-tabler-eye"
            :severity="
              isEditorPreview
                ? 'primary'
                : 'secondary'
            "
            text
            @click="togglePreviewMenu"
          />
        </div>
      </div>

      <!--
        =====================================================
        AVANT / APRÈS
        =====================================================
      -->
      <div
        v-if="!isEditorPreview"
        class="hidden lg:flex history-actions"
      >
        <Button
          :label="$t('ui.topbar.undo')"
          icon="i-tabler-arrow-left"
          severity="secondary"
          text
          :disabled="!canUndo"
          @click="undo"
        />

        <Button
          :label="$t('ui.topbar.redo')"
          icon="i-tabler-arrow-right"
          icon-pos="right"
          severity="secondary"
          text
          :disabled="!canRedo"
          @click="redo"
        />
      </div>
    </template>

    <template #end>
      <!--
        =====================================================
        NAVIGATION À DROITE
        =====================================================
      -->
      <div class="hidden lg:flex topbar-right">
        <TopbarPageButton
          :label="$t('ui.topbar.editor')"
          icon="i-tabler-map"
          to="/editor"
        />

        <TopbarPageButton
          v-if="isEditorRoute"
          label="CLU Métropole"
          icon="i-tabler-train"
          to="/game"
        />

        <Button
          class="unified-menu-button"
          label="="
          severity="secondary"
          text
          rounded
          aria-label="Réseaux et préférences"
          title="Réseaux et préférences"
          @click="toggleUtilityMenu"
        />

        <template v-if="isWinter">
          <Divider
            layout="vertical"
            pt:root:class="important-mx-1"
          />

          <Button
            text
            rounded
            :icon="
              snowEnabled
                ? 'i-tabler-snowflake'
                : 'i-tabler-snowflake-off'
            "
            @click="toggleSnow()"
          />
        </template>
      </div>

      <!--
        =====================================================
        MENU MOBILE
        =====================================================
      -->
      <Button
        pt:root:class="lg:important-hidden"
        icon="i-tabler-menu-2"
        severity="secondary"
        text
        rounded
        @click="showMenu = true"
      />
    </template>
  </Menubar>

  <!--
    =========================================================
    MENU FICHIER
    =========================================================
  -->
  <Popover
    ref="filePopover"
    class="topbar-popover"
  >
    <div class="popover-content file-popover-content">
      <div class="popover-heading">
        <div class="popover-heading-icon">
          <i class="i-tabler-file" />
        </div>

        <div>
          <div class="popover-title">
            {{ $t('ui.topbar.file') }}
          </div>

          <div class="popover-subtitle">
            {{ $t('ui.topbar.file_subtitle') }}
          </div>
        </div>
      </div>

      <Divider />

      <div class="file-menu-wrapper">
        <MainMenu
          :preview-limited="isRatpEditorPreview"
          @open-custom-indices="openCustomIndices"
          @open-mode-pictograms="openModePictograms"
          @open-save="openSave"
        />
      </div>
    </div>
  </Popover>

  <!--
    =========================================================
    MENU OUTILS
    =========================================================
  -->
  <Popover
    ref="toolsPopover"
    class="topbar-popover"
  >
    <div class="popover-content tools-popover-content">
      <div class="popover-heading">
        <div class="popover-heading-icon">
          <i class="i-tabler-adjustments-horizontal" />
        </div>

        <div>
          <div class="popover-title">
            {{ $t('ui.topbar.tools') }}
          </div>

          <div class="popover-subtitle">
            {{ $t('ui.topbar.tools_subtitle') }}
          </div>
        </div>
      </div>

      <Divider />

      <div class="tools-settings">
        <GeneralMapSettings
          @open-custom-map-size="openCustomMapSize"
          @open-custom-line-thickness="openCustomLineThickness"
        />
      </div>
    </div>
  </Popover>

  <!--
    =========================================================
    CHOIX DE PRÉVISUALISATION
    =========================================================
  -->
  <Popover
    ref="previewPopover"
    class="topbar-popover"
  >
    <div class="popover-content preview-popover-content">
      <div class="popover-heading">
        <div class="popover-heading-icon">
          <i class="i-tabler-eye" />
        </div>

        <div>
          <div class="popover-title">
            {{ $t('ui.map_editor.preview_title') }}
          </div>

          <div class="popover-subtitle">
            {{ $t('ui.map_editor.preview_subtitle') }}
          </div>
        </div>
      </div>

      <Divider />

      <div class="preview-options">
        <Button
          v-for="option in previewOptions"
          :key="option.mode"
          :label="$t(option.labelKey)"
          :icon="option.icon"
          :severity="
            previewMode === option.mode
              ? 'primary'
              : 'secondary'
          "
          text
          @click="selectPreviewMode(option.mode)"
        />
      </div>

      <template v-if="isEditorPreview">
        <Divider />

        <Button
          :label="$t('ui.map_editor.back_to_editing')"
          icon="i-tabler-edit"
          severity="secondary"
          text
          @click="returnToEditing"
        />
      </template>
    </div>
  </Popover>

  <!--
    =========================================================
    RÉSEAUX / THÈME / TRADUCTION
    =========================================================
  -->
  <Popover
    ref="utilityPopover"
    class="topbar-popover"
  >
    <div class="popover-content utility-popover-content">
      <a
        class="utility-menu-link"
        href="https://x.com/Bot_CLU"
        target="_blank"
        rel="noopener noreferrer"
        aria-label="X (Twitter)"
        @click="closeUtilityMenu"
      >
        <i class="i-tabler-brand-x" />
        <span>X / Twitter</span>
      </a>

      <a
        class="utility-menu-link"
        href="https://discord.gg/EPt3scCQH8"
        target="_blank"
        rel="noopener noreferrer"
        aria-label="Discord CLU"
        @click="closeUtilityMenu"
      >
        <i class="i-tabler-brand-discord" />
        <span>Discord</span>
      </a>

      <Divider />

      <div class="utility-setting-row">
        <div class="utility-setting-label">
          <i class="i-tabler-palette" />
          <span>Thème</span>
        </div>

        <ThemeSwitcher />
      </div>

      <div class="utility-setting-row">
        <div class="utility-setting-label">
          <i class="i-tabler-language" />
          <span>Traduction</span>
        </div>

        <LocaleSwitcher />
      </div>
    </div>
  </Popover>

  <!--
    =========================================================
    MENU MOBILE
    =========================================================
  -->
  <Dialog
    v-model:visible="showMenu"
    :header="$t('ui.topbar.menu')"
    pt:root:class="w-full"
    modal
  >
    <div class="mobile-menu">
      <div class="mobile-section">
        <div class="mobile-section-title">
          {{ $t('ui.topbar.file') }}
        </div>

        <MainMenu
          :preview-limited="isRatpEditorPreview"
          @open-custom-indices="openCustomIndices"
          @open-mode-pictograms="openModePictograms"
          @open-save="openSave"
        />
      </div>

      <template v-if="!isEditorPreview">
        <Divider />

        <div class="mobile-section">
          <div class="mobile-section-title">
            {{ $t('ui.topbar.tools') }}
          </div>

          <GeneralMapSettings
            @open-custom-map-size="openCustomMapSize"
            @open-custom-line-thickness="openCustomLineThickness"
          />
        </div>
      </template>

      <template v-if="isEditorRoute">
        <Divider />

        <div class="mobile-section">
          <div class="mobile-section-title">
            {{ $t('ui.map_editor.preview_title') }}
          </div>

          <Button
            v-for="option in previewOptions"
            :key="option.mode"
            :label="$t(option.labelKey)"
            :icon="option.icon"
            :severity="
              previewMode === option.mode
                ? 'primary'
                : 'secondary'
            "
            size="large"
            @click="selectPreviewModeFromMobile(option.mode)"
          />

          <Button
            v-if="isEditorPreview"
            :label="$t('ui.map_editor.back_to_editing')"
            icon="i-tabler-edit"
            severity="secondary"
            size="large"
            @click="returnToEditingFromMobile"
          />
        </div>
      </template>

      <Divider />

      <TopbarPageButton
        :label="$t('ui.topbar.editor')"
        icon="i-tabler-map"
        to="/editor"
        size="large"
        @click="showMenu = false"
      />

      <TopbarPageButton
        v-if="isEditorRoute"
        label="CLU Métropole"
        icon="i-tabler-train"
        to="/game"
        size="large"
        @click="showMenu = false"
      />

      <div class="mobile-social-links">
        <a
          class="mobile-social-link"
          href="https://x.com/Bot_CLU"
          target="_blank"
          rel="noopener noreferrer"
          aria-label="X (Twitter)"
          @click="showMenu = false"
        >
          <i class="i-tabler-brand-x" />

          <span>
            X
          </span>
        </a>

        <a
          class="mobile-social-link"
          href="https://discord.gg/EPt3scCQH8"
          target="_blank"
          rel="noopener noreferrer"
          aria-label="Discord CLU"
          @click="showMenu = false"
        >
          <i class="i-tabler-brand-discord" />

          <span>
            Discord
          </span>
        </a>
      </div>

      <Divider />

      <div class="mobile-footer">
        <ThemeSwitcher />
        <LocaleSwitcher />

        <Button
          v-if="isWinter"
          text
          rounded
          :icon="
            snowEnabled
              ? 'i-tabler-snowflake'
              : 'i-tabler-snowflake-off'
          "
          @click="toggleSnow()"
        />
      </div>
    </div>
  </Dialog>

  <!--
    =========================================================
    FENÊTRES DU MENU FICHIER

    Elles sont volontairement placées EN DEHORS du Popover.
    Ainsi, fermer le menu Fichier ne détruit plus la fenêtre
    actuellement ouverte.
    =========================================================
  -->
  <CustomLineIndexDirectoryDialog
    v-model:visible="showLineIndexDirectory"
  />

  <CustomModePictogramsDialog
    v-model:visible="showModePictogramsDialog"
  />

  <SaveDialog
    v-model:visible="showSaveDialog"
  />

  <!--
    =========================================================
    FENÊTRE DE TAILLE PERSONNALISÉE

    Cette fenêtre reste volontairement en dehors du Popover
    Outils. Elle n'est donc pas détruite lorsque le Popover
    se ferme.
    =========================================================
  -->
  <Dialog
    v-model:visible="showCustomMapSizeDialog"
    :header="$t('ui.dialogs.custom_map_size.header')"
    modal
    append-to="body"
    :dismissable-mask="false"
    @hide="customMapSize = project.line.mapSize"
  >
    <InputGroup>
      <BInputNumber
        v-model="customMapSize"
        class="w-full"
      />

      <InputGroupAddon>
        <span>em</span>
      </InputGroupAddon>
    </InputGroup>

    <template #footer>
      <Button
        :label="$t('ui.common.cancel')"
        severity="secondary"
        @click="cancelCustomMapSize"
      />

      <Button
        :label="$t('ui.dialogs.custom_map_size.accept')"
        @click="applyCustomMapSize"
      />
    </template>
  </Dialog>

  <!--
    =========================================================
    FENÊTRE D'ÉPAISSEUR PERSONNALISÉE

    Comme la fenêtre de taille personnalisée, elle reste
    volontairement en dehors du Popover Outils.
    =========================================================
  -->
  <Dialog
    v-model:visible="showCustomLineThicknessDialog"
    :header="$t('ui.dialogs.custom_line_thickness.header')"
    modal
    append-to="body"
    :dismissable-mask="false"
    @hide="customLineThickness = project.line.lineThickness"
  >
    <InputGroup>
      <BInputNumber
        v-model="customLineThickness"
        class="w-full"
      />

      <InputGroupAddon>
        <span>em</span>
      </InputGroupAddon>
    </InputGroup>

    <template #footer>
      <Button
        :label="$t('ui.common.cancel')"
        severity="secondary"
        @click="cancelCustomLineThickness"
      />

      <Button
        :label="$t('ui.dialogs.custom_line_thickness.accept')"
        @click="applyCustomLineThickness"
      />
    </template>
  </Dialog>
  </template>
</template>

<style scoped lang="scss">
/*
 * =========================================================
 * BARRE SUPÉRIEURE
 * =========================================================
 */

.bulb-topbar {
  position: relative;
  z-index: 100;
}

.topbar-left,
.topbar-right,
.topbar-actions {
  display: flex;
  flex-direction: row;
  align-items: center;
}

.topbar-left {
  min-width: 0;
}

.topbar-right {
  gap: .25rem;
}

.topbar-actions {
  gap: .15rem;
}

.social-link {
  display: inline-flex;
  align-items: center;
  justify-content: center;

  width: 2.5rem;
  height: 2.5rem;

  border-radius: 50%;

  color: var(--p-text-color);
  text-decoration: none;

  font-size: 1.2rem;

  transition:
    background-color .15s ease,
    color .15s ease;
}

.social-link:hover {
  background: var(--p-content-hover-background);
}

.social-link:focus-visible {
  outline:
    2px solid
    var(--p-primary-color);
  outline-offset: 2px;
}

.brand {
  display: flex;
  flex-direction: row;
  align-items: center;

  margin-right: 1rem;
}

.brand-title {
  margin: 0;

  font-size: 1.875rem;
  line-height: 1.2;
}

/*
 * =========================================================
 * AVANT / APRÈS
 * =========================================================
 */

.history-actions {
  position: absolute;
  top: 50%;
  left: 50%;

  z-index: 5;

  flex-direction: row;
  align-items: center;
  gap: .15rem;

  transform: translate(-50%, -50%);
}

/*
 * =========================================================
 * POPOVERS
 * =========================================================
 */

.popover-content {
  display: flex;
  flex-direction: column;

  padding: .15rem;
}

.file-popover-content {
  width: 22rem;
}

.tools-popover-content {
  width: 24rem;
  max-height: min(44rem, calc(100vh - 7rem));
}

.preview-popover-content {
  width: 22rem;
}

.utility-popover-content {
  width: 15.5rem;
  gap: .15rem;
}

.unified-menu-button {
  min-width: 2.5rem;
  height: 2.5rem;

  font-size: 1.35rem;
  font-weight: 700;
  line-height: 1;
}

.utility-menu-link,
.utility-setting-row {
  min-height: 2.6rem;

  display: flex;
  align-items: center;

  border-radius: .5rem;

  color: var(--p-text-color);
  text-decoration: none;
}

.utility-menu-link {
  gap: .75rem;
  padding: .55rem .75rem;

  transition: background-color .15s ease;
}

.utility-menu-link:hover {
  background: var(--p-content-hover-background);
}

.utility-menu-link:focus-visible {
  outline: 2px solid var(--p-primary-color);
  outline-offset: 2px;
}

.utility-menu-link > i,
.utility-setting-label > i {
  width: 1.25rem;

  flex-shrink: 0;

  font-size: 1.15rem;
  text-align: center;
}

.utility-setting-row {
  justify-content: space-between;
  gap: .75rem;
  padding: .3rem .35rem .3rem .75rem;
}

.utility-setting-label {
  display: inline-flex;
  align-items: center;
  gap: .75rem;

  min-width: 0;
}

.preview-options {
  display: flex;
  flex-direction: column;
  align-items: stretch;
}

.preview-options :deep(.p-button) {
  justify-content: flex-start;
}

.popover-heading {
  display: flex;
  flex-direction: row;
  align-items: center;
  gap: .75rem;

  padding: .35rem .35rem 0;
}

.popover-heading-icon {
  display: flex;
  align-items: center;
  justify-content: center;

  width: 2.25rem;
  height: 2.25rem;

  flex-shrink: 0;

  border-radius: .75rem;

  background:
    var(--p-content-hover-background);

  font-size: 1.2rem;
}

.popover-title {
  font-size: 1rem;
  font-weight: 700;
}

.popover-subtitle {
  margin-top: .1rem;

  color: var(--p-text-muted-color);

  font-size: .75rem;
}

.tools-settings {
  overflow-y: auto;

  padding-right: .25rem;
}

/*
 * Les libellés du menu Fichier restent alignés à gauche
 * lorsqu'ils occupent plusieurs lignes.
 */
.file-menu-wrapper {
  :deep(.p-button) {
    justify-content: flex-start;
    text-align: left;
  }

  :deep(.p-button-label) {
    flex: initial;

    white-space: normal;
    text-align: left;
  }
}

/*
 * =========================================================
 * MOBILE
 * =========================================================
 */

.mobile-menu {
  display: flex;
  flex-direction: column;
  gap: .5rem;
}

.mobile-section {
  display: flex;
  flex-direction: column;
  gap: .5rem;
}

.mobile-section-title {
  font-size: 1rem;
  font-weight: 700;
}

.mobile-social-links {
  display: grid;
  grid-template-columns: repeat(2, minmax(0, 1fr));
  gap: .5rem;
}

.mobile-social-link {
  display: flex;
  align-items: center;
  justify-content: center;
  gap: .5rem;

  min-height: 2.75rem;
  padding: .55rem .75rem;

  border-radius: .65rem;

  background: transparent;

  color: var(--p-text-color);
  text-decoration: none;

  font-size: .9rem;
  font-weight: 600;

  transition:
    background-color .15s ease,
    color .15s ease;
}

.mobile-social-link i {
  font-size: 1.2rem;
}

.mobile-social-link:hover {
  background: var(--p-content-hover-background);
}

.mobile-social-link:focus-visible {
  outline:
    2px solid
    var(--p-primary-color);
  outline-offset: 2px;
}

.mobile-footer {
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: space-evenly;

  padding: 0 .5rem;
}

/*
 * =========================================================
 * PETITS ÉCRANS
 * =========================================================
 */

@media (max-width: 1280px) {
  .brand {
    margin-right: .5rem;
  }
}
</style>